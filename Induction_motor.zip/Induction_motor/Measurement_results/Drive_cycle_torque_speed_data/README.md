CREATOR Project A01: Induction Motor Drive Cycle Torque Speed Data

Electric Drives and Power Electronic Systems Insititute (EALS), TU Graz

## Description
This folder contains input data for drive cycles specifically designed for an induction motor (IM).
 The motor is located in the EALS Machines Laboratory at TU Graz and is known as the CREATOR test case motor.
 
 

## Usage

        Folder:  Mid_sized_vehicle
         
         
Contained within this folder are downscaled torque and speed inputs for the IM, referencing the BMW i3, often referred to as a medium-range vehicle (mid).
 The provided drive cycles include Wltp class 3, Artemis Motorway (130km/hr), and Braunschweig City Driving Cycle (BCDC).
 These operating points are derived from the longitudinal vehicle model of the BMW i3, as thoroughly described in the paper available in the longitudinal vehicle model folder.
This paper offers an in-depth explanation of both the longitudinal vehicle model and the vehicle specifications.


Each data set is stored as both .mat and .csv files. Each file contains two columns: the first column is time in seconds, and the second column includes data for torque in Nm and speed in rpm.
        Folder:  Small_sized_vehicle
         
Within this folder are downscaled torque and speed inputs designed for the IM, with reference to the SmartEQ, recognized as a small-range vehicle. 
Included are drive cycles such as Wltp class 3, Artemis Motorway (130km/hr), and Braunschweig City Driving Cycle (BCDC).
These operating points are derived from the longitudinal vehicle model of the Smart EQ, as thoroughly described in the paper available in the longitudinal vehicle model folder.
This paper offers an in-depth explanation of both the longitudinal vehicle model and the vehicle specifications.


Each data set is stored as both .mat and .csv files. Each file contains two columns: the first column is time in seconds, and the second column includes data for torque in Nm and speed in rpm. 
 

        Folder:  Longitudinal_vehicle_model
        
This folder comprises of  a published  paper elucidating the longitudinal vehicle model employed to compute the requires torque and speed profiles for various drive cycles.
 Additionally, it includes specifications for both the BMW i3 and Smart EQ vehicles, serving as reference vehicle models for this project.
 
 
 


## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249
