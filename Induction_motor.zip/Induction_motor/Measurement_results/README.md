CREATOR Project A01: Induction Motor Measurements Data

Electric Drives and Power Electronic Systems Insititute (EALS), TU Graz

## Description
Contained within these folders are measurement data pertaining to the induction motor (IM) housed in the EALS Machines Laboratory at TU Graz, known as the CREATOR test case motor.

## Usage

        Folder:  Locked_rotor_and_no_load_tests
         
This folder contains MATLAB data files with results from locked-rotor and no-load tests used to analyze IM electrical parameters.
 A PDF document presenting all MATLAB results and measurement data is also included.
 
        Folder:  Drive_cycle_measurement_results
         
This folder contains measurements of six different drive cycles. The results of the analysis for each drive cycle can be found in separate folders within this directory.
These drive cycle operating points are obtained from two different vehicles across three distinct drive cycles.
 
Drive cycles: Wltp class 3, Artemis Motorway (130km/hr), Braunchewig City Driving Cycle (BCDC)
Vehicles: Mid range (mid)..> BMW i3, Small range (small)..>Smart EQ
 
        Folder:  Drive_cycle_torque_speed_data
          
This folder contains various drive cycle data used for testing the IM, calculated based on the specifications of BMW i3 and SmartEQ vehicles.          

        Folder:  Equivalent_circuit_parameters
        
This folder comprises the equivalent circuit parameters of the IM calculated from experimental measurements.	


## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support
Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249
