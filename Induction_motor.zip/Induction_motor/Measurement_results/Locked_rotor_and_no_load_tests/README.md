CREATOR Project A01: Induction Motor No-load and Locked-rotor tests results

Electric Drives and Power Electronic Systems Institute (EALS), TU Graz

## Description
This folder contains data from the no-load and locked rotor tests conducted on the induction motor (IM) at the EALS Machines Lab of TU Graz.
This particular motor is designated as the CREATOR test case motor.



## Usage

        File: Locked_rotor_data.mat
        
This file contains data from the locked-rotor test conducted on 01/10/2019. The test was performed under various supply frequencies and voltages to determine the rotor resistance and leakage inductances.

        File: No_load_data.mat
        
Enclosed within this file is the dataset derived from a no-load test conducted on 25/09/2019, encompassing diverse supply frequencies and voltage amplitudes. The primary objective of this examination was to assess the magnetization inductances and ascertain the iron losses of the motor under scrutiny.

**Note: These .mat files contain a single struct object comprising six fields. The first field represents the terminal voltage in volts RMS (Vs),the second field denotes the stator current in amperes RMS (Is), the third field signifies the active power of the motor (P), the fourth field indicates the frequency at which each measurement was taken (f), the fifth field holds the torque data obtained from torque measurements (Tshaft), and the sixth field stores the stator resistances of each phase (Rs). Each row within the struct corresponds to a specific frequency measurement. To access the data within the struct, you would utilize the syntax: struct_name(row_number).field_name. For instance, to retrieve the current data related to the second frequency or row, you would write struct_name(2).Is**

        File: Pfe_flux_sq.csv

This .csv file contains the iron losses of the IM at different frequencies based on the stator flux linkage squared. Each pair of columns corresponds to the same frequency: the first column represents the stator flux linkage squared (Flux_sq_**Hz), and the second column shows the amount of iron losses (Pfe1_**Hz) for that flux.

        File: Pfw_flux_sq.csv

This .csv file contains the sum of friction and windage losses of the IM at different frequencies based on the stator flux linkage squared. Each pair of columns corresponds to the same frequency: the first column represents the stator flux linkage squared (Flux_sq_**Hz), and the second column shows the sum of friction and windage losses (Pfw_**Hz) for that flux.

## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249
