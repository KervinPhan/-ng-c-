CREATOR Project A01: Induction Motor Drive Cycle Measurement Result

Electric Drives and Power Electronic Systems Insititute (EALS), TU Graz

## Description
This folder contains the drive cycle measurement results (input power and output power) for the induction motor (IM) tested in the EALS laboratory at TU Graz. 
The measurements correspond to the input torque and speed data provided in the "Drive_cycle_torque_speed_data" folder.
  For each drive cycle input, both the input power and output power measurement results are provided.
 
 

## Usage

            Folder: Mid_sized_vehicle
Contained within this folder are the drive cycle measurement results for PMSM, referencing the BMW i3, often referred to as a medium-range vehicle (mid).
 The provided measurement results include drive cycles  Wltp class 3, Artemis Motorway (130km/hr), and Braunschweig City Driving Cycle (BCDC). 
Each drive cycle includes input power and output power data sets, which are stored as both .mat and .csv files. Each data set has two columns: the first column represents time in seconds, and the second column represents power in watts.

            Folder: Small_sized_vehicle
Contained within this folder are the drive cycle measurement results for PMSM, with reference to the SmartEQ, recognized as a small-range vehicle (small).
 The provided measurement results include drive cycles  Wltp class 3, Artemis Motorway (130km/hr), and Braunschweig City Driving Cycle (BCDC).
Each drive cycle includes input power and output power data sets, which are stored as both .mat and .csv files. Each data set has two columns: the first column represents time in seconds, and the second column represents power in watts.
 



## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249
