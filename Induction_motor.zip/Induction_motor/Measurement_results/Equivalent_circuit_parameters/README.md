CREATOR Project A01: Induction Motor Equivalent Circuit Parameters

Electric Drives and Power Electronic Systems Institute, TU Graz


## Description

These files contain the electrical parameters derived from diverse experimental tests carried out on the induction motor (IM) used in the EALS LAB at TU Graz.
## Usage

In the following text, the details of each file for electrical parameter of the IM will be explained:

        File:  Equivalent_circuit_parameters.csv

This document thoroughly details all electrical parameters derived from experiments conducted on IM.
 
        Files:  Rr.mat and Rr.csv

These files present a tabular representation illustrating the relationship between frequency and rotor resistance, alongside data showcasing the dependency of rotor resistance on frequency.

The .mat  and .csv files consist of two columns of data. The first column represents frequency values, while the second column corresponds to the rotor resistance measured at each frequency.

        Files:  Lm.mat and Lm.csv

This document provides insights into the interplay among magnetization current (in Amperes RMS), magnetization flux (in Volts-seconds RMS), and magnetization inductance (in Henrys) obtained from measurements. It includes data showcasing the relationship among these variables, crucial for motor control and simulation.
Moreover, the data is structured with the first column representing magnetization current, the second column representing magnetization flux, and the third column representing magnetization inductance.
This dataset serves as essential data for comprehending the magnetic behavior of the motor, facilitating precise modeling and analysis of its characteristics.

        File:  L_sigmas.mat and L_sigmas.csv

These files contain detailed data on the electrical parameters of the IM, including stator leakage inductance (Lσs) and rotor leakage inductance (Lσr), across various frequencies.  The dataset consists of three columns: frequency in Hertz (first column), stator leakage inductances in Henrys (second column) and rotor leakage inductances in Henrys (third column). 
All these parameters were obtained from locked rotor tests and no-load tests, providing essential insights into the motor's electrical characteristics.           

        File:  Equivalent_circuit.pdf

This file contains the IEEE equivalant circuit of the IM.


## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249