CREATOR Project A01: Induction Motor

Electric Drives and Power Electronic Systems Institute (EALS), TU Graz

## Description
This folders containes the specifications and measurement data of the induction motor (IM).  This motor is in the [EALS](https://www.eals.tugraz.at) machines LAB of the TU Graz and is the [CREATOR](https://www.tu-darmstadt.de/trr361/news_trr361/index.en.jsp) test case motor.

## Usage

        Folder:  Design_parameters
This folder contains the specification  and  parameters  of IM. it includes electrical,  material, geometry, and winding properties of the induction motor.

        Folder:  Measurement_results

This folder contains laboratory measurements for different drive cycle torque speed data inputs of an induction motor, located in the Drive Cycle Torque Speed Data folder. It also includes results from no-load and locked rotor 
tests conducted at various frequencies. Moreover, it contains the calculated equivalent circuit parameters derived from these experiments.

        File:  IM_overview.xlsx

This file provides an overview of the specifications of the induction motor. The information presented here is general, and for more detailed information,
 it is recommended to refer to the specific folders provided in the design_parameters folder, which cover electrical, geometry, material, and winding properties.
 
         File:  IM_general_specification.csv

This file details the general specification of the IM. 

         File:  Motor_pictures.pdf

This .pdf file includes two pictures of the motor. The left one is after the manufacturing process, where the cooling jacket is insulated, and the right one shows the completed stator winding during the manufacturing process.

       
        



## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249