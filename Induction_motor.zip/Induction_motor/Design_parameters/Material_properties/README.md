CREATOR Project A01: Induction Motor Materiak Properties

Electric Drives and Power Electronic Systems Institute, TU Graz

## Description
These files pertain to the material specifications of parts for an induction motor (IM). The IM is utilized in the EALS LAB at TU Graz.

## Usage

In the following text, the details of each file will be explained:

                File:  Motor_parts_material.csv

This document presents a table detailing the materials used for various parts of the IM.

                Folder:  Insulation_of_stator_winding_materials

This folder contains the properties of epoxy resin (wire insulation) and insulation materials for various components, including slot liners, inter-phase, end winding, and winding overhang insulation of the IM. It includes thermal, mechanical, and electrical properties.

                Folder:  Copper

The files in this folder  present the thermal and electrical specifications of the copper wire employed in the IM's stator winding. 

                Folder:  Stator_and_rotor_iron

This folder contains a file outlining the thermal, electrical, and mechanical properties of the steel sheet used for both stator and rotor iron components in the IM. It includes specifications for different frequencies, along with magnetization characteristics and other relevant data. A folder named **stator_and_rotor_iron** contains separate .csv files with detailed data for each frequency.
In each .csv file of **stator_and_rotor_iron** folder has 4 columns that presents flux density, magnetic field strength, specific iron loss, and relative permeability.
           
                Folder:  Rotor_cage_and_cooling_jacket_material
                        
 This files in this folder detail the material properties of the aluminum cage  and cooling jacket utilized in the IM, covering thermal, mechanical, and electrical characteristics.

                Folder:  Shaft_steel
                        
 It includes specifications regarding the material used for the shaft of the IM.

                   



## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249