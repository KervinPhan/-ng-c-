CREATOR Project A01: Induction Motor Design Parameters

Electric Drives and Power Electronic Systems Institute, TU Graz


## Description
These files encompass the design parameter  obtained from both manufacturing data and various experimental 
analyses conducted on the induction motor (IM) utilized in the EALS LAB at TU Graz.
## Usage

		Folder:  Electrical_parameters
        
This folder contains the electrical parameters pertinent to the motor's operation, encompassing working voltages, currents, and frequency for the IM.

		Folder:  Material_properties
This folder contains information on the different material properties .

		Folder: Motor_geometry
This folder contains comprehensive information detailing the geometry of the motor components.
		
		Folder: Winding_scheme
This folder contains information about the winding scheme of the stator winding in the IM.
 
 

## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249

   