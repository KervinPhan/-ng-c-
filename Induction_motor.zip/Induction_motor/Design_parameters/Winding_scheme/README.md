CREATOR Project A01: Induction Motor Winding Scheme

Electric Drives and Power Electronic Systems Institute, TU Graz

## Description
These files contain crucial information about the winding configuration for an induction motor (IM) used in the EALS LAB at TU Graz

## Usage

In the following text, the details of each file will be explained:

                file:  Winding_scheme.pdf

This document contains the designation of each phase of windings, coil names, the number of turns for the coils, and model view of the winding configuration.	

                file:  Winding_properties_of_IM.csv
                
It contains winding parameters utilized for the motor design, alongside various winding configuration properties and parameters.




## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone: +43 316 873 - 7249