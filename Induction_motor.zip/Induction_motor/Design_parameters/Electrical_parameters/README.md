CREATOR Project A01: Induction Motor Electrical Parameters

Electric Drives and Power Electronic Systems Institute, TU Graz


## Description
These files encompass the electrical parameter specifications obtained from both manufacturing data and various experimental 
analyses conducted on the induction motor (IM) utilized in the EALS LAB at TU Graz
## Usage

In the following text, the details of each file for electrical parameter of induction motor will be explained:

            File:  Electrical_parameter_of_IM.csv

This .csv file comprehensively outlines all the electrical parameters of the induction motor, providing crucial insights into its operational characteristics.
 
 


## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249

 