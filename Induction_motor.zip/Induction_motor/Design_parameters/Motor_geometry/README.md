CREATOR Project A01: Induction Motor  Motor Geometry 

Electric Drives and Power Electronic Systems Institute, TU Graz

## Description
These files contain detailed geometry data for various components of an induction motor (IM) utilized in the EALS LAB at TU Graz
## Usage

In the following text, the details of each file will be explained:

                File:  Geometry_parameters.csv
                        
This file contains parameters extracted from manufacturer data that are not directly mentioned in other files. It offers supplementary 
geometry information crucial for a comprehensive understanding of the motor's structure and components.

                File:  IM_motor_geometry.pdf 

This file contains the figure of the motor geometry with precise dimensions.
                   
                Folder:	2D_cad_files
This  folder contains the version 1 of IM geometry cad files for corresponding use cases. 


## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/

## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249