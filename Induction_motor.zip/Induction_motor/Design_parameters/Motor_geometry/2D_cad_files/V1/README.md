CREATOR Project A01: Induction Motor Motor CAD Files

Electric Drives and Power Electronic Systems Institute, TU Graz

## Description
The CAD files in this repository pertain to the Induction Motor (IM) located within the EALS laboratory of TU Graz. 
These CAD files serve the purpose of providing users with ready-to-use models, eliminating the need for them to create the designs from scratch.
 However, users retain the option to redraw the geometries according to their preferences using the provided specifications.

The .dxf file is derived from the JMAG model of the IM, while the .step file is generated from the .dxf file using FreeCAD software. 
Finally, the .jou file is produced from the .step file utilizing CoreForm-Cubit software under an academic free license.

## Author:

Kourosh Heidarikani

## License

This work is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/


## Support

Kourosh Heidarikani

k.heidarikani@tugraz.at

Phone:  +43 316 873 - 7249